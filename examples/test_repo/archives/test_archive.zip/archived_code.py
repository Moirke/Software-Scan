# TODO: Fix this bug in the archived code
# This file will be included in test_archive.zip

def buggy_function():
    # FIXME: This needs proper error handling
    password = "temporary_password"
    return password
